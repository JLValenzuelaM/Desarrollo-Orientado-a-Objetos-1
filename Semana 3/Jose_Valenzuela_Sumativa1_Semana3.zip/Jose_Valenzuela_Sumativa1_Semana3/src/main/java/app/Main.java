package app;

import model.Direccion;
import model.Empleado;
import model.Persona;

/** Punto de entrada: muestra ejemplos de clientes y colaboradores. */
public class Main {
    public static void main(String[] args) {
        Direccion direccionCliente = new Direccion("Costanera", "145", "Llanquihue", "Los Lagos");
        Direccion direccionGuia = new Direccion("Vicente Pérez Rosales", "820", "Puerto Varas", "Los Lagos");
        Direccion direccionOperaciones = new Direccion("Baquedano", "210", "Llanquihue", "Los Lagos");

        Persona cliente = new Persona("Camila Soto", "18.234.567-8", "camila.soto@example.cl",
                "+56 9 6123 4567", direccionCliente);
        Empleado guia = new Empleado("Diego Alvarado", "16.345.678-9", "diego.alvarado@example.cl",
                "+56 9 7234 5678", direccionGuia, "Guía turístico", "LT-001");
        Empleado coordinadora = new Empleado("Fernanda Ruiz", "17.456.789-0", "fernanda.ruiz@example.cl",
                "+56 9 8345 6789", direccionOperaciones, "Coordinadora de operaciones", "LT-002");

        System.out.println("=== Llanquihue Tour | Personas registradas ===");
        System.out.println(cliente);
        System.out.println(guia);
        System.out.println(coordinadora);
    }
}
