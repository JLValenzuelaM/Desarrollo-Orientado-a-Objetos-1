package model;

/** Persona que trabaja para la agencia en un rol determinado. */
public class Empleado extends Persona {
    private String cargo;
    private String codigoEmpleado;

    public Empleado(String nombre, String rut, String correo, String telefono,
                    Direccion direccion, String cargo, String codigoEmpleado) {
        super(nombre, rut, correo, telefono, direccion);
        setCargo(cargo);
        setCodigoEmpleado(codigoEmpleado);
    }

    public String getCargo() { return cargo; }
    public void setCargo(String cargo) { this.cargo = requerido(cargo, "cargo"); }
    public String getCodigoEmpleado() { return codigoEmpleado; }
    public void setCodigoEmpleado(String codigoEmpleado) {
        this.codigoEmpleado = requerido(codigoEmpleado, "código de empleado");
    }

    @Override
    public String toString() {
        return "Empleado{nombre='" + getNombre() + "', rut='" + getRut() + "', correo='" + getCorreo()
                + "', teléfono='" + getTelefono() + "', dirección=" + getDireccion()
                + ", cargo='" + cargo + "', código='" + codigoEmpleado + "'}";
    }
}
