package model;

/** Datos comunes de clientes y colaboradores de Llanquihue Tour. */
public class Persona {
    private String nombre;
    private String rut;
    private String correo;
    private String telefono;
    private Direccion direccion;

    public Persona(String nombre, String rut, String correo, String telefono, Direccion direccion) {
        setNombre(nombre);
        setRut(rut);
        setCorreo(correo);
        setTelefono(telefono);
        setDireccion(direccion);
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = requerido(nombre, "nombre"); }
    public String getRut() { return rut; }
    public void setRut(String rut) { this.rut = requerido(rut, "RUT"); }
    public String getCorreo() { return correo; }
    public void setCorreo(String correo) {
        String valor = requerido(correo, "correo");
        if (!valor.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            throw new IllegalArgumentException("El correo no tiene un formato válido.");
        }
        this.correo = valor;
    }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = requerido(telefono, "teléfono"); }
    public Direccion getDireccion() { return direccion; }
    public void setDireccion(Direccion direccion) {
        if (direccion == null) throw new IllegalArgumentException("La dirección es obligatoria.");
        this.direccion = direccion;
    }

    protected static String requerido(String valor, String nombre) {
        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException("El " + nombre + " es obligatorio.");
        }
        return valor.trim();
    }

    @Override
    public String toString() {
        return "Persona{nombre='" + nombre + "', rut='" + rut + "', correo='" + correo
                + "', teléfono='" + telefono + "', dirección=" + direccion + "}";
    }
}
