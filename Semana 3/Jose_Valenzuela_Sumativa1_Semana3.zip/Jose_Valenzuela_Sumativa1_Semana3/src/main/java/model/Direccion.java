package model;

/** Dirección física asociada a una persona. */
public class Direccion {
    private String calle;
    private String numero;
    private String comuna;
    private String region;

    public Direccion(String calle, String numero, String comuna, String region) {
        setCalle(calle);
        setNumero(numero);
        setComuna(comuna);
        setRegion(region);
    }

    public String getCalle() { return calle; }
    public void setCalle(String calle) { this.calle = requerido(calle, "calle"); }
    public String getNumero() { return numero; }
    public void setNumero(String numero) { this.numero = requerido(numero, "número"); }
    public String getComuna() { return comuna; }
    public void setComuna(String comuna) { this.comuna = requerido(comuna, "comuna"); }
    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = requerido(region, "región"); }

    private static String requerido(String valor, String nombre) {
        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException("La " + nombre + " es obligatoria.");
        }
        return valor.trim();
    }

    @Override
    public String toString() {
        return calle + " " + numero + ", " + comuna + ", " + region;
    }
}
