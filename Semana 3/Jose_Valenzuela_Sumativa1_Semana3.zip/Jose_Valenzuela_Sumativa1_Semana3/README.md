# Llanquihue Tour

Prototipo Java para modelar personas vinculadas a una agencia de turismo de la comuna de Llanquihue.

## Modelo

- `model.Persona`: clase base con datos comunes y atributos privados.
- `model.Empleado`: extiende `Persona` y agrega cargo y código de empleado.
- `model.Direccion`: objeto compuesto dentro de cada persona, con calle, número, comuna y región.
- `app.Main`: crea un cliente, un guía y una coordinadora, e imprime sus datos.

El constructor y los setters validan campos obligatorios y el formato básico del correo. La dirección se representa como composición: cada persona recibe y mantiene su dirección como parte de sus datos. La separación en paquetes `model` y `app` mantiene el dominio aparte del punto de entrada.

## Ejecutar

Requiere JDK 17 o superior. Desde esta carpeta, con Maven instalado:

```bash
mvn compile
mvn exec:java -Dexec.mainClass=app.Main
```

También puede abrirse como proyecto Maven en IntelliJ IDEA. Si se ejecuta directamente desde el IDE, seleccionar `app.Main` como clase principal.
